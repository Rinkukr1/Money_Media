package Services;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

//import com.mysql.cj.protocol.Resultset;

import Connection.HiberConfig;
import Users.New_User;
public class UserServiices {
	SessionFactory sf=HiberConfig.conn();
	Session sc=null;	
	public String Add_User(New_User user) {
		String result=null;
		sc=sf.openSession();
		Transaction ts=sc.beginTransaction();
		
		Serializable rs=sc.save(user);
		ts.commit();
		
		if(rs!=null) {
			result="success";
		}
		sc.close();
		return result;
	}
	
	public List<New_User> Search(New_User user){
//		List<New_User> user_list=null;
		sc=sf.openSession();
		TypedQuery qry=sc.createQuery("from New_User where email=:em and password=:pass");
		qry.setParameter("em", user.getEmail());
		qry.setParameter("pass", user.getPassword());
//		qry.setParameter("pass", user.getPassword());
		
	    List<New_User> user_list=qry.getResultList();

		if(user_list.isEmpty())
			return null;
			
		return user_list;
	}
	
	public String Chnage_pass(String email,String New_Pass){
		String result=null;
		sc=sf.openSession();
		TypedQuery qry=sc.createQuery("update New_User set password=:pass where email=:em");
		qry.setParameter("em", email);
		qry.setParameter("pass", New_Pass);
		
		int res=qry.executeUpdate();
			
		if(res>=1) {
			result="success";
		}
		return result;
	}
	
	public List<New_User> Search_One(String email){
//		List<New_User> user_list=null;
		sc=sf.openSession();
		TypedQuery qry=sc.createQuery("from New_User where email=:em");
		qry.setParameter("em", email);
//		qry.setParameter("pass", user.getPassword());
//		qry.setParameter("pass", user.getPassword());
		
	    List<New_User> user_list=qry.getResultList();

		if(user_list.isEmpty())
			return null;
			
		return user_list;
	}
}
