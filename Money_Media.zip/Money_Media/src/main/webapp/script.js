// script.js
document.addEventListener("DOMContentLoaded", function () {
    const forgotPasswordLink = document.getElementById("forgot-password");
    const modal = document.getElementById("forgot-password-modal");
    const closeBtn = document.querySelector(".close");

    forgotPasswordLink.addEventListener("click", function (e) {
        e.preventDefault();
        modal.style.display = "block";
    });

    closeBtn.addEventListener("click", function () {
        modal.style.display = "none";
    });

    window.addEventListener("click", function (e) {
        if (e.target === modal) {
            modal.style.display = "none";
        }
    });

    const loginForm = document.getElementById("login-form");
    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();
        // Add login functionality here (in a real app, it would send a request to the server)
        alert("Login submitted");
    });

    const registrationForm = document.getElementById("registration-form");
    registrationForm.addEventListener("submit", function (e) {
        e.preventDefault();
        // Add registration functionality here (in a real app, it would send a request to the server)
        alert("Registration submitted");
    });

    const resetPasswordButton = document.getElementById("reset-password-button");
    resetPasswordButton.addEventListener("click", function () {
        // Add forgot password functionality here (in a real app, it would send a reset password request to the server)
        alert("Password reset request submitted");
        modal.style.display = "none";
    });
});
